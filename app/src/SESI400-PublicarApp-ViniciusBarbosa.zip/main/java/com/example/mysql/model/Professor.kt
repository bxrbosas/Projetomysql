package com.example.mysql.model

data class  Professor (
    val id: Int,
    val nome: String,
    val cpf: String,
    val email: String
)