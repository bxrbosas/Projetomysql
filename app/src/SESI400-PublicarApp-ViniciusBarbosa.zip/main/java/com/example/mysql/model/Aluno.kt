package com.example.mysql.model

data class Aluno(
    val id: Int,
    val nome: String,
    val cpf: String,
    val email: String,
    val matricula: String
)
